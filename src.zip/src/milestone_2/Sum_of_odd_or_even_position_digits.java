package milestone_2;
import java.util.*;
public class Sum_of_odd_or_even_position_digits {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner ip=new Scanner(System.in);
		int input1=ip.nextInt(),input2=ip.nextInt(),input3=ip.nextInt(),input4=ip.nextInt();
		ip.close();
		System.out.println(pin(input1,input2,input3,input4));
	}
	public static int pin(int input1, int input2, int input3, int input4) {
		 
		int a[]= {input1/1000, input1/100%10, input1/10%10, input1%10}; 
		int b[]= {input2/1000, input2/100%10, input2/10%10, input2%10}; 
		int c[]= {input3/1000, input3/100%10, input3/10%10, input3%10}; 
				if(input4%2==1)	return(a[1]+a[3]+b[1]+b[3]+c[1]+c[3])-(a[0]+a[2]+b[0]+b[2]+c[0]+c[2]);				
				else return(a[0]+a[2]+b[0]+b[2]+c[0]+c[2])-(a[1]+a[3]+b[1]+b[3]+c[1]+c[3]);
}
}
