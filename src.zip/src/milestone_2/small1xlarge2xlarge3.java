package milestone_2;
import java.util.*;
public class small1xlarge2xsmall3 {

	public static void main(String[] args) {
		Scanner ip=new Scanner(System.in);
		int input1=ip.nextInt(),input2=ip.nextInt(),input3=ip.nextInt(),input4=ip.nextInt();
		ip.close();
		int a1[]= {input1/1000, input1/100%10, input1/10%10, input1%10}; Arrays.sort(a1);
		int a2[]= {input2/1000, input2/100%10, input2/10%10, input2%10}; Arrays.sort(a2);
		int a3[]= {input3/1000, input3/100%10, input3/10%10, input3%10}; Arrays.sort(a3);
		int result=(a1[0]*a2[3]*a3[3])+input4;
		System.out.println(result);
	}

}
