package milestone_2;

public class Sum_of_non_prime_index_values {

	public static void main(String[] args) {
		int a[]= {10,20,30,40,50,60,70,80,90,100};
		System.out.println(nonprime(a));
	}
		public static int nonprime(int input1[]) {
			int sum=0;
			for(int i=0; i<input1.length; i++)
			{
				int count=0;
				for(int j=1; j<=i; j++)
				{
					if(i%j==0)
						count++;
				}
				if(count!=2)
					sum=sum+input1[i];
			}
			return sum;
		}
}
