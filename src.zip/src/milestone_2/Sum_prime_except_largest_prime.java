package milestone_2;

import java.util.Arrays;

public class Sum_prime_except_largest_prime {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
			int a[]= {10,41,18,50,43,31,29,25,59,96,67};
			System.out.println(nonprime(a));
		}
		public static int nonprime(int input1[]) {
			int sum=0;
			int a[]=new int[input1.length];
			for(int i=0; i<input1.length; i++)
			{
				int count=0;
				for(int j=1; j<=input1[i]; j++)
				{
					if(input1[i]%j==0)
						count++;
				}
				if(count==2)
					a[i]=input1[i];
			}
			Arrays.sort(a);
			int min=Integer.MIN_VALUE;
			for(int i=0; i<a.length;i++)
			{
				if(a[i]!=0) {
				if(min<=a[i])
					min=a[i];
				}
				sum+=a[i];
			}
			return sum-min;
	}

}
