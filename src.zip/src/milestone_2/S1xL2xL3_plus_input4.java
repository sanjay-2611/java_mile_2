package milestone_2;
import java.util.*;
public class S1xL2xL3_plus_input4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner ip=new Scanner(System.in);
		int input1=ip.nextInt(),input2=ip.nextInt(),input3=ip.nextInt(),input4=ip.nextInt();
		ip.close();
		System.out.println(result(input1,input2,input3,input4));
	}
	public static int result(int input1,int input2,int input3,int input4) {
		int a[]= {input1/1000, input1/100%10, input1/10%10, input1%10}; Arrays.sort(a);
		int b[]= {input2/1000, input2/100%10, input2/10%10, input2%10}; Arrays.sort(b);
		int c[]= {input3/1000, input3/100%10, input3/10%10, input3%10}; Arrays.sort(c);
				int result=a[0]*b[3]*c[3]+input4;
		return result;
	}

}
