package milestone_2;

import java.util.Scanner;

public class pin_minus_11 {

	public static void main(String[] args) {
		Scanner ip=new Scanner(System.in);
		int input1=ip.nextInt(),input2=ip.nextInt(),input3=ip.nextInt(),input4=ip.nextInt();
		ip.close();
		System.out.println(pin(input1,input2,input3,input4));
	}
	public static int pin(int input1, int input2, int input3, int input4) {
		int a[]= {input1/1000, input1/100%10, input1/10%10, input1%10,input2/1000, input2/100%10, input2/10%10, input2%10,input3/1000, input3/100%10, input3/10%10, input3%10}; 
				int sum=0,sum2=0;
		for(int i=0; i<a.length; i++)
				{
				if(input4%2==0)
				{
					if(a[i]%2==0)
					sum+=a[i];
					else sum2+=a[i];
				}
				else  {
					if(a[i]%2==1)
						sum+=a[i];
						else sum2+=a[i];
				}
		}
		return(sum-sum2);
	}




	}


