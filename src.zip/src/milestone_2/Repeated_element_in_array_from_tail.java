package milestone_2;

public class Repeated_element_in_array_from_tail {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[]= {1,2,4,1,2,8};
		System.out.println(nonprime(a,a.length));
	}
		public static int nonprime(int input1[],int input2) {
			int count=0;
			for(int i=0; i<input2; i++) {
				if(input1[i]<0||input1[i]==0)
					count++;
			}
			if(count==input2)
			{return 0;}
			else {
			int sum=0;
			first:
			for(int i=input1.length-1; i>=0; i--)
			{
				for(int j=i-1; j>=0; j--)
				{
					if(input1[i]==input1[j]) {
						sum=input1[j];
					break first;
					}					
				}
				
			}
			if(sum==0) {
				return input1[input2-1];
			}
			else
			return sum;
			}
			
			
	}

}
